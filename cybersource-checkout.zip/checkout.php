<?php
date_default_timezone_set('UTC');

$access_key = "bea9bb4a9de232d2bff7c4774efb1899";
$profile_id = "4236A71B-61AC-435B-89BE-D87D35634AD0";
$secret_key = "67d2598800f14504aec345d487701246eb9a9c04ffe3422787ea2c8e54f81a17a15dc9f5056d469ba3593afd9dd6e994a09520399cee4a62aa690dc3b60ce2c96c8a804a77fb491d950ada070b04d8a3f666dba8d4cf4a7697aabb7dc15fa32a90191109e3504b5eacd39e208e0762c7112b8e4af95e403888007f5a661e8e2b";

$transaction_uuid = uniqid();
$reference_number = uniqid("order_");
$signed_date_time = gmdate("Y-m-d\TH:i:s\Z");

$signed_field_names = "access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency";

$fields = [
    "access_key" => $access_key,
    "profile_id" => $profile_id,
    "transaction_uuid" => $transaction_uuid,
    "signed_field_names" => $signed_field_names,
    "unsigned_field_names" => "",
    "signed_date_time" => $signed_date_time,
    "locale" => "en",
    "transaction_type" => "sale",
    "reference_number" => $reference_number,
    "amount" => "10.00",
    "currency" => "USD"
];

function sign($params, $secret_key) {
    $signedFieldNames = explode(",", $params["signed_field_names"]);
    $dataToSign = [];
    foreach ($signedFieldNames as $field) {
        $dataToSign[] = $field . "=" . $params[$field];
    }
    $data = implode(",", $dataToSign);
    return base64_encode(hash_hmac('sha256', $data, $secret_key, true));
}

$signature = sign($fields, $secret_key);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>دفع CyberSource تجريبي</title>
</head>
<body>
    <h2>ادفع الآن (تجربة بيئة تجريبية)</h2>
    <form method="post" action="https://testsecureacceptance.cybersource.com/checkout">
        <?php foreach ($fields as $name => $value): ?>
            <input type="hidden" name="<?= htmlspecialchars($name) ?>" value="<?= htmlspecialchars($value) ?>">
        <?php endforeach; ?>
        <input type="hidden" name="signature" value="<?= htmlspecialchars($signature) ?>">
        <button type="submit">Pay Now</button>
    </form>
</body>
</html>
